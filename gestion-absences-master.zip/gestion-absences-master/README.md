# gestion-absences
Application java qui fait la gestion d'absences des étudiants
[to read](https://github.com/OthmanMoussaoui/gestion-absences/files/9233635/Projet.Bases.de.donnees.Avancees.2.pdf)
