/*    */ package DAO;
/*    */ 
/*    */ import Entités.Personne;
/*    */ import Technique.CRUDE;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthentificationDAO
/*    */ {
/* 17 */   CRUDE crude = new CRUDE();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Personne athentification(String login, String pwd) {
/* 23 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\otman\Downloads\Gestion-D-Absences--master\Gestion_Des_Absences.jar!\DAO\AuthentificationDAO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */