package Entités;

public class Personne {}


/* Location:              C:\Users\otman\Downloads\Gestion-D-Absences--master\Gestion_Des_Absences.jar!\Entit�s\Personne.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */